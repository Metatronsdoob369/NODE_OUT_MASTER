Liquid Glass effect using SVG filters (https://github.com/shuding/svg-shaders).

## Demo

https://v0.dev/chat/dynamic-frame-layout-1VUCCecq7Uy.

## Usage

Simply paste https://github.com/shuding/liquid-glass/blob/main/liquid-glass.js into any website console.

## Example

![CleanShot 2025-06-11 at 12 02 53@2x](https://github.com/user-attachments/assets/81e618c3-c157-4962-a076-f5334221ee57)
