const functions = require("firebase-functions");
const admin = require("firebase-admin");
const OpenAI = require("openai");

admin.initializeApp();
const db = admin.firestore();

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

exports.generateTemplate = functions.https.onRequest(async (req, res) => {
  const { coreId, title, sourceType } = req.body;
  const prompt = `You are a Creative Text Transformation Assistant... Book Title: ${title} Source Type: ${sourceType}`;

  try {
    const chat = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "system", content: "You are a creative assistant." }, { role: "user", content: prompt }],
    });

    const parsed = JSON.parse(chat.choices[0].message?.content || "{}");
    await db.collection("thoughtCores").doc(coreId).update({ ...parsed, status: "complete", updatedAt: new Date() });

    res.status(200).json({ success: true, data: parsed });
  } catch (err) {
    console.error("[GPT Error]", err);
    res.status(500).json({ error: "Template generation failed", message: err.message });
  }
});
