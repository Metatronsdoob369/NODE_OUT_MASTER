import React, { useState } from 'react';
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Outlet, Navigate } from 'react-router-dom';
import Waitlist from './Waitlist';
import ActivatePanel from './ActivatePanel';
import PATHsassin3DMermaid from './PATHsassin3DMermaid';
import NodeLanding from './pages/NodeLanding';
import PATHsassin3D from './pages/PATHsassin3D';
import AgentInterface from './pages/AgentInterface';
import NotFound from './pages/NotFound';

function AppLayout() {
  return <Outlet />;
}

function App() {
  return (
    <Router>
      <Routes>
        <Route element={<AppLayout />}>
          <Route path="/" element={<NodeLanding />} />
          <Route path="/pathsassin-3d" element={<PATHsassin3D />} />
          <Route path="/agent" element={<AgentInterface />} />
          <Route path="*" element={<NotFound />} />
        </Route>
      
<Route path=\"/waitlist\" element={<Waitlist />} />
</Routes>
    </Router>
  );
}

export default App;