import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { BrowserRouter as Router, Routes, Route, Outlet } from 'react-router-dom';
import NodeLanding from './pages/NodeLanding';
import PATHsassin3D from './pages/PATHsassin3D';
import AgentInterface from './pages/AgentInterface';
import NotFound from './pages/NotFound';
function AppLayout() {
    return _jsx(Outlet, {});
}
function App() {
    return (_jsx(Router, { children: _jsx(Routes, { children: _jsxs(Route, { element: _jsx(AppLayout, {}), children: [_jsx(Route, { path: "/", element: _jsx(NodeLanding, {}) }), _jsx(Route, { path: "/pathsassin-3d", element: _jsx(PATHsassin3D, {}) }), _jsx(Route, { path: "/agent", element: _jsx(AgentInterface, {}) }), _jsx(Route, { path: "*", element: _jsx(NotFound, {}) })] }) }) }));
}
export default App;
