import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Sphere, MeshDistortMaterial } from '@react-three/drei';
import * as THREE from 'three';

// The Four Layers of Being
const ConsciousnessLayers = {
  BODY: {
    name: "Body",
    radius: 2,
    color: "#ff6b6b",
    description: "Physical mastery, practical skills, tangible knowledge",
    glow: "#ff0000",
    opacity: 0.8
  },
  SPIRIT: {
    name: "Spirit", 
    radius: 5,
    color: "#4ecdc4",
    description: "Emotional intelligence, creative force, intuition",
    glow: "#00ffff",
    opacity: 0.5
  },
  I_AM: {
    name: "I Am",
    radius: 8,
    color: "#ffe66d", 
    description: "Self-awareness, identity, sovereign consciousness",
    glow: "#ffff00",
    opacity: 0.3
  },
  CONSCIOUSNESS: {
    name: "Universal Consciousness",
    radius: 15,
    color: "#a8dadc",
    description: "Unity, transcendence, omniscient awareness",
    glow: "#ffffff",
    opacity: 0.1
  }
};

// Central Multi-Layered Core Component
const MultidimensionalCore = ({ masteredByLayer, consciousnessActivated }) => {
  const coreRef = useRef(null);
  const tetrahedronRef = useRef(null);
  const sacredGroupRef = useRef(null);
  
  useFrame((state) => {
    if (coreRef.current) {
      // Each layer rotates at different speeds
      coreRef.current.children.forEach((child, index) => {
        child.rotation.y = state.clock.elapsedTime * (0.1 + index * 0.05);
        child.rotation.x = state.clock.elapsedTime * (0.05 + index * 0.02);
      });
    }
    
    // Rotate sacred geometry
    if (tetrahedronRef.current) {
      tetrahedronRef.current.rotation.y = state.clock.elapsedTime * 0.3;
      tetrahedronRef.current.rotation.z = state.clock.elapsedTime * 0.2;
    }
    
    // Counter-rotate the sacred geometry group
    if (sacredGroupRef.current) {
      sacredGroupRef.current.rotation.y = -state.clock.elapsedTime * 0.1;
    }
  });

  return (
    <group ref={coreRef}>
      {/* Body Core - Dense, Physical */}
      <Sphere args={[ConsciousnessLayers.BODY.radius, 32, 32]}>
        <meshStandardMaterial
          color={ConsciousnessLayers.BODY.color}
          emissive={ConsciousnessLayers.BODY.glow}
          emissiveIntensity={masteredByLayer.body.length * 0.1}
          metalness={0.9}
          roughness={0.1}
          opacity={ConsciousnessLayers.BODY.opacity}
          transparent
        />
      </Sphere>
      
      {/* Spirit Layer - Ethereal, Flowing */}
      <Sphere args={[ConsciousnessLayers.SPIRIT.radius, 24, 24]}>
        <MeshDistortMaterial
          color={ConsciousnessLayers.SPIRIT.color}
          emissive={ConsciousnessLayers.SPIRIT.glow}
          emissiveIntensity={masteredByLayer.spirit.length * 0.15}
          metalness={0.5}
          roughness={0.5}
          opacity={ConsciousnessLayers.SPIRIT.opacity}
          transparent
          distort={0.3}
          speed={2}
        />
      </Sphere>
      
      {/* I Am Layer - Radiant Self-Awareness */}
      <Sphere args={[ConsciousnessLayers.I_AM.radius, 16, 16]}>
        <meshBasicMaterial
          color={ConsciousnessLayers.I_AM.color}
          opacity={ConsciousnessLayers.I_AM.opacity}
          transparent
          wireframe
        />
      </Sphere>
      
      {/* Universal Consciousness - Only visible when activated */}
      {consciousnessActivated && (
        <Sphere args={[ConsciousnessLayers.CONSCIOUSNESS.radius, 32, 32]}>
          <meshBasicMaterial
            color={ConsciousnessLayers.CONSCIOUSNESS.color}
            opacity={ConsciousnessLayers.CONSCIOUSNESS.opacity}
            transparent
            wireframe={false}
          />
        </Sphere>
      )}
      
      {/* Sacred Geometry Overlay */}
      <group>
        {/* Central Icosahedron */}
        <mesh ref={tetrahedronRef} scale={[1, 1.5, 1]}>
          <icosahedronGeometry args={[4, 1]} />
          <meshBasicMaterial
            color="#ffffff"
            opacity={0.05}
            transparent
            wireframe
            side={THREE.DoubleSide}
          />
        </mesh>
        
        {/* Rotating Sacred Geometry Layers */}
        <group ref={sacredGroupRef}>
          {/* Octahedron - Purple */}
          <mesh rotation={[0, 0, Math.PI / 4]}>
            <octahedronGeometry args={[3.5, 0]} />
            <meshBasicMaterial 
              color="#ff00ff" 
              opacity={0.05} 
              transparent 
              wireframe 
            />
          </mesh>
          
          {/* Dodecahedron - Green */}
          <mesh rotation={[Math.PI / 4, 0, 0]}>
            <dodecahedronGeometry args={[3.5, 0]} />
            <meshBasicMaterial 
              color="#00ff00" 
              opacity={0.05} 
              transparent 
              wireframe 
            />
          </mesh>
          
          {/* Tetrahedron - Cyan */}
          <mesh rotation={[0, Math.PI / 3, Math.PI / 6]}>
            <tetrahedronGeometry args={[6, 0]} />
            <meshBasicMaterial 
              color="#00ffff" 
              opacity={0.03} 
              transparent 
              wireframe 
            />
          </mesh>
        </group>
      </group>
    </group>
  );
};

export default MultidimensionalCore;