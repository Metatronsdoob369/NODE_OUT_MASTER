import React, { useRef, useMemo, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Line, Sphere, Html, MeshDistortMaterial, Float } from '@react-three/drei';
import * as THREE from 'three';
import { motion } from 'framer-motion';

interface SkillNode {
  id: string;
  name: string;
  layer: 'body' | 'spirit' | 'i_am';
  progress: number;
  level: string;
  position: [number, number, number];
  color: string;
  connections: string[];
  description: string;
  orbitRadius: number;
  orbitSpeed: number;
  angle: number;
}

// Consciousness Layer Definitions
const ConsciousnessLayers = {
  BODY: {
    name: "Body",
    radius: 2,
    color: "#ff6b6b",
    description: "Physical mastery, practical skills, tangible knowledge",
    glow: "#ff4444",
    opacity: 0.9
  },
  SPIRIT: {
    name: "Spirit",
    radius: 4,
    color: "#4ecdc4",
    description: "Emotional intelligence, creative force, intuition",
    glow: "#00ffff",
    opacity: 0.6
  },
  I_AM: {
    name: "I Am",
    radius: 6,
    color: "#ffe66d",
    description: "Self-awareness, identity, sovereign consciousness",
    glow: "#ffff00",
    opacity: 0.4
  },
  CONSCIOUSNESS: {
    name: "Universal Consciousness",
    radius: 20,
    color: "#ffffff",
    description: "Unity, transcendence, omniscient awareness",
    glow: "#ffffff",
    opacity: 0.15
  }
};

// Particle system for cosmic atmosphere
const CosmicField: React.FC<{ density: number; consciousnessLevel: number }> = ({ density, consciousnessLevel }) => {
  const particlesRef = useRef<THREE.Points>(null);
  
  const particles = useMemo(() => {
    const positions = new Float32Array(density * 3);
    const colors = new Float32Array(density * 3);
    
    for (let i = 0; i < density; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos((Math.random() * 2) - 1);
      const r = 15 + Math.random() * 10;
      
      positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      positions[i * 3 + 2] = r * Math.cos(phi);
      
      const intensity = 0.3 + (consciousnessLevel / 13) * 0.7;
      colors[i * 3] = intensity;
      colors[i * 3 + 1] = intensity * 0.8;
      colors[i * 3 + 2] = intensity;
    }
    
    return { positions, colors };
  }, [density, consciousnessLevel]);
  
  useFrame((state) => {
    if (particlesRef.current) {
      particlesRef.current.rotation.y = state.clock.elapsedTime * 0.02;
    }
  });
  
  return (
    <points ref={particlesRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={particles.positions.length / 3}
          array={particles.positions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-color"
          count={particles.colors.length / 3}
          array={particles.colors}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial size={0.1} vertexColors transparent opacity={0.8} />
    </points>
  );
};

// Multi-dimensional Core
const MultidimensionalCore: React.FC<{
  masteredByLayer: {
    body: string[];
    spirit: string[];
    i_am: string[];
  };
  consciousnessActivated: boolean;
}> = ({ masteredByLayer, consciousnessActivated }) => {
  const coreRef = useRef<THREE.Group>(null);
  const bodyRef = useRef<THREE.Mesh>(null);
  const spiritRef = useRef<THREE.Mesh>(null);
  const iAmRef = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    // Body rotates fastest
    if (bodyRef.current) {
      bodyRef.current.rotation.y = state.clock.elapsedTime * 0.3;
    }
    // Spirit rotates moderately
    if (spiritRef.current) {
      spiritRef.current.rotation.y = state.clock.elapsedTime * 0.15;
      spiritRef.current.rotation.x = state.clock.elapsedTime * 0.1;
    }
    // I Am rotates slowly
    if (iAmRef.current) {
      iAmRef.current.rotation.y = state.clock.elapsedTime * 0.05;
      iAmRef.current.rotation.z = state.clock.elapsedTime * 0.03;
    }
  });

  return (
    <group ref={coreRef}>
      {/* Body Core */}
      <Sphere ref={bodyRef} args={[ConsciousnessLayers.BODY.radius, 32, 32]}>
        <meshStandardMaterial
          color={ConsciousnessLayers.BODY.color}
          emissive={ConsciousnessLayers.BODY.glow}
          emissiveIntensity={0.3 + masteredByLayer.body.length * 0.1}
          metalness={0.8}
          roughness={0.2}
          transparent
          opacity={ConsciousnessLayers.BODY.opacity}
        />
      </Sphere>
      
      {/* Spirit Layer */}
      <Sphere ref={spiritRef} args={[ConsciousnessLayers.SPIRIT.radius, 24, 24]}>
        <MeshDistortMaterial
          color={ConsciousnessLayers.SPIRIT.color}
          emissive={ConsciousnessLayers.SPIRIT.glow}
          emissiveIntensity={0.2 + masteredByLayer.spirit.length * 0.1}
          metalness={0.5}
          roughness={0.5}
          transparent
          opacity={ConsciousnessLayers.SPIRIT.opacity}
          distort={0.2}
          speed={2}
        />
      </Sphere>
      
      {/* I Am Layer */}
      <Sphere ref={iAmRef} args={[ConsciousnessLayers.I_AM.radius, 16, 16]}>
        <meshBasicMaterial
          color={ConsciousnessLayers.I_AM.color}
          transparent
          opacity={ConsciousnessLayers.I_AM.opacity}
          wireframe
        />
      </Sphere>
      
      {/* Sacred Geometry */}
      <mesh rotation={[0, 0, 0]}>
        <tetrahedronGeometry args={[3, 0]} />
        <meshBasicMaterial
          color="#ffffff"
          opacity={0.1}
          transparent
          wireframe
        />
      </mesh>
      
      {/* Universal Consciousness */}
      {consciousnessActivated && (
        <Sphere args={[ConsciousnessLayers.CONSCIOUSNESS.radius, 48, 48]}>
          <meshBasicMaterial
            color={ConsciousnessLayers.CONSCIOUSNESS.color}
            transparent
            opacity={ConsciousnessLayers.CONSCIOUSNESS.opacity}
          />
        </Sphere>
      )}
      
      <Html position={[0, 0, 0]} center>
        <div className="text-center pointer-events-none">
          <div className="text-white/90 text-xs mb-1">
            Body: {masteredByLayer.body.length}
          </div>
          <div className="text-cyan-400/90 text-xs mb-1">
            Spirit: {masteredByLayer.spirit.length}
          </div>
          <div className="text-yellow-400/90 text-xs">
            I Am: {masteredByLayer.i_am.length}
          </div>
        </div>
      </Html>
    </group>
  );
};

// Orbital Skill Node
const OrbitalSkillNode: React.FC<{
  node: SkillNode;
  isSelected: boolean;
  onSelect: (id: string) => void;
  isMastered: boolean;
}> = ({ node, isSelected, onSelect, isMastered }) => {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);
  const groupRef = useRef<THREE.Group>(null);
  
  useFrame((state) => {
    if (groupRef.current) {
      const time = state.clock.elapsedTime;
      const x = Math.cos(node.angle + time * node.orbitSpeed) * node.orbitRadius;
      const z = Math.sin(node.angle + time * node.orbitSpeed) * node.orbitRadius;
      const y = node.layer === 'body' ? 0 : node.layer === 'spirit' ? 2 : 4;
      
      groupRef.current.position.set(x, y, z);
    }
  });
  
  const layerColors = {
    body: "#ff6b6b",
    spirit: "#4ecdc4",
    i_am: "#ffe66d"
  };
  
  return (
    <Float speed={1} rotationIntensity={0.1} floatIntensity={0.2}>
      <group ref={groupRef}>
        {/* Mastery glow */}
        {isMastered && (
          <Sphere args={[0.8, 16, 16]}>
            <meshBasicMaterial
              color="#ffffff"
              transparent
              opacity={0.3}
            />
          </Sphere>
        )}
        
        {/* Main node */}
        <Sphere
          ref={meshRef}
          args={[0.5, 32, 32]}
          onPointerOver={() => {
            setHovered(true);
            document.body.style.cursor = 'pointer';
          }}
          onPointerOut={() => {
            setHovered(false);
            document.body.style.cursor = 'default';
          }}
          onClick={(e) => {
            e.stopPropagation();
            onSelect(node.id);
          }}
        >
          <meshStandardMaterial
            color={isMastered ? "#ffffff" : layerColors[node.layer]}
            emissive={isMastered ? "#ffffff" : layerColors[node.layer]}
            emissiveIntensity={isMastered ? 0.6 : (hovered ? 0.4 : 0.2)}
            metalness={0.7}
            roughness={0.3}
          />
        </Sphere>
        
        {/* Progress ring */}
        <mesh rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[0.6, 0.02, 8, 32, (node.progress / 100) * Math.PI * 2]} />
          <meshBasicMaterial color={layerColors[node.layer]} opacity={0.8} transparent />
        </mesh>
        
        <Html position={[0, 0.8, 0]} center>
          <div className={`text-xs font-bold px-2 py-1 rounded-full backdrop-blur-sm pointer-events-none ${
            isMastered
              ? 'bg-white/90 text-black'
              : 'bg-black/60 text-white border border-white/30'
          }`}>
            {node.name}
          </div>
        </Html>
      </group>
    </Float>
  );
};

// Orbital Paths
const OrbitalPath: React.FC<{ radius: number; height: number; color: string }> = ({ 
  radius, height, color
}) => {
  return (
    <group position={[0, height, 0]}>
      <mesh rotation={[-Math.PI / 2, 0, 0]}>
        <torusGeometry args={[radius, 0.02, 8, 64]} />
        <meshBasicMaterial
          color={color}
          transparent
          opacity={0.2}
        />
      </mesh>
    </group>
  );
};

// Main Scene Component (inside Canvas)
const Scene: React.FC<{
  masteredSkills: string[];
  selectedNode: string | null;
  setSelectedNode: (id: string | null) => void;
  skillNodes: SkillNode[];
  consciousnessActivated: boolean;
  masteredByLayer: {
    body: string[];
    spirit: string[];
    i_am: string[];
  };
}> = ({ masteredSkills, selectedNode, setSelectedNode, skillNodes, consciousnessActivated, masteredByLayer }) => {
  return (
    <>
      {/* Lighting */}
      <ambientLight intensity={0.1} />
      <pointLight position={[0, 0, 0]} intensity={0.8} color="#ffffff" />
      <pointLight position={[10, 10, 10]} intensity={0.3} color="#4ecdc4" />
      <pointLight position={[-10, -10, -10]} intensity={0.3} color="#ffe66d" />
      
      {/* Controls */}
      <OrbitControls
        enablePan={true}
        enableZoom={true}
        enableRotate={true}
        maxDistance={40}
        minDistance={10}
        autoRotate={true}
        autoRotateSpeed={0.3}
      />
      
      {/* Cosmic field */}
      <CosmicField density={2000} consciousnessLevel={masteredSkills.length} />
      
      {/* Multi-dimensional core */}
      <MultidimensionalCore
        masteredByLayer={masteredByLayer}
        consciousnessActivated={consciousnessActivated}
      />
      
      {/* Orbital paths */}
      <OrbitalPath radius={10} height={0} color="#ff6b6b" />
      <OrbitalPath radius={14} height={2} color="#4ecdc4" />
      <OrbitalPath radius={18} height={4} color="#ffe66d" />
      
      {/* Skill nodes */}
      {skillNodes.map((node) => (
        <OrbitalSkillNode
          key={node.id}
          node={node}
          isSelected={selectedNode === node.id}
          onSelect={setSelectedNode}
          isMastered={masteredSkills.includes(node.id)}
        />
      ))}
    </>
  );
};

const PATHsassin3DMermaid: React.FC = () => {
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [masteredSkills, setMasteredSkills] = useState<string[]>(['stoicism', 'n8n']);
  
  const skillNodes: SkillNode[] = [
    // Body Layer
    {
      id: 'n8n',
      name: 'Automation',
      layer: 'body',
      progress: 85,
      level: 'ADVANCED',
      position: [0, 0, 0],
      color: '#ff6b6b',
      connections: ['webdesign', 'executive'],
      description: 'Workflow automation mastery',
      orbitRadius: 10,
      orbitSpeed: 0.2,
      angle: 0
    },
    {
      id: 'webdesign',
      name: 'Web Design',
      layer: 'body',
      progress: 55,
      level: 'INTERMEDIATE',
      position: [0, 0, 0],
      color: '#ff6b6b',
      connections: ['n8n', 'graphicdesign'],
      description: 'Digital architecture',
      orbitRadius: 10,
      orbitSpeed: 0.2,
      angle: Math.PI / 2
    },
    {
      id: 'graphicdesign',
      name: 'Visual Design',
      layer: 'body',
      progress: 40,
      level: 'BEGINNER',
      position: [0, 0, 0],
      color: '#ff6b6b',
      connections: ['webdesign'],
      description: 'Visual communication',
      orbitRadius: 10,
      orbitSpeed: 0.2,
      angle: Math.PI
    },
    {
      id: 'executive',
      name: 'Executive',
      layer: 'body',
      progress: 30,
      level: 'NOVICE',
      position: [0, 0, 0],
      color: '#ff6b6b',
      connections: ['n8n', 'leadership'],
      description: 'Strategic execution',
      orbitRadius: 10,
      orbitSpeed: 0.2,
      angle: 3 * Math.PI / 2
    },
    // Spirit Layer
    {
      id: 'leadership',
      name: 'Leadership',
      layer: 'spirit',
      progress: 45,
      level: 'BEGINNER',
      position: [0, 2, 0],
      color: '#4ecdc4',
      connections: ['stoicism', 'motivation'],
      description: 'Inspiring teams',
      orbitRadius: 14,
      orbitSpeed: 0.15,
      angle: 0
    },
    {
      id: 'motivation',
      name: 'Motivation',
      layer: 'spirit',
      progress: 60,
      level: 'INTERMEDIATE',
      position: [0, 2, 0],
      color: '#4ecdc4',
      connections: ['leadership', 'mentorship'],
      description: 'Influence and inspiration',
      orbitRadius: 14,
      orbitSpeed: 0.15,
      angle: Math.PI / 2
    },
    {
      id: 'mentorship',
      name: 'Mentorship',
      layer: 'spirit',
      progress: 65,
      level: 'INTERMEDIATE',
      position: [0, 2, 0],
      color: '#4ecdc4',
      connections: ['motivation', 'stoicism'],
      description: 'Guiding others',
      orbitRadius: 14,
      orbitSpeed: 0.15,
      angle: Math.PI
    },
    {
      id: 'stoicism',
      name: 'Stoicism',
      layer: 'spirit',
      progress: 75,
      level: 'INTERMEDIATE',
      position: [0, 2, 0],
      color: '#4ecdc4',
      connections: ['mentorship', 'leadership'],
      description: 'Emotional mastery',
      orbitRadius: 14,
      orbitSpeed: 0.15,
      angle: 3 * Math.PI / 2
    },
    // I Am Layer
    {
      id: 'language',
      name: 'Language',
      layer: 'i_am',
      progress: 25,
      level: 'NOVICE',
      position: [0, 4, 0],
      color: '#ffe66d',
      connections: ['theosophy', 'business'],
      description: 'Universal communication',
      orbitRadius: 18,
      orbitSpeed: 0.1,
      angle: 0
    },
    {
      id: 'business',
      name: 'Business',
      layer: 'i_am',
      progress: 35,
      level: 'BEGINNER',
      position: [0, 4, 0],
      color: '#ffe66d',
      connections: ['language', 'finance'],
      description: 'Commerce wisdom',
      orbitRadius: 18,
      orbitSpeed: 0.1,
      angle: 2 * Math.PI / 5
    },
    {
      id: 'finance',
      name: 'Finance',
      layer: 'i_am',
      progress: 20,
      level: 'NOVICE',
      position: [0, 4, 0],
      color: '#ffe66d',
      connections: ['business', 'government'],
      description: 'Economic understanding',
      orbitRadius: 18,
      orbitSpeed: 0.1,
      angle: 4 * Math.PI / 5
    },
    {
      id: 'government',
      name: 'Governance',
      layer: 'i_am',
      progress: 15,
      level: 'NOVICE',
      position: [0, 4, 0],
      color: '#ffe66d',
      connections: ['finance', 'theosophy'],
      description: 'Systems of order',
      orbitRadius: 18,
      orbitSpeed: 0.1,
      angle: 6 * Math.PI / 5
    },
    {
      id: 'theosophy',
      name: 'Philosophy',
      layer: 'i_am',
      progress: 50,
      level: 'INTERMEDIATE',
      position: [0, 4, 0],
      color: '#ffe66d',
      connections: ['government', 'language'],
      description: 'Universal wisdom',
      orbitRadius: 18,
      orbitSpeed: 0.1,
      angle: 8 * Math.PI / 5
    }
  ];

  const masteredByLayer = {
    body: masteredSkills.filter(id => 
      skillNodes.find(n => n.id === id)?.layer === 'body'
    ),
    spirit: masteredSkills.filter(id => 
      skillNodes.find(n => n.id === id)?.layer === 'spirit'
    ),
    i_am: masteredSkills.filter(id => 
      skillNodes.find(n => n.id === id)?.layer === 'i_am'
    )
  };
  
  const consciousnessActivated = masteredSkills.length === 13;

  const testProgression = () => {
    const allSkillIds = skillNodes.map(n => n.id);
    const unmasteredSkills = allSkillIds.filter(id => !masteredSkills.includes(id));
    
    if (unmasteredSkills.length > 0) {
      const nextSkill = unmasteredSkills[0];
      setMasteredSkills([...masteredSkills, nextSkill]);
    } else {
      setMasteredSkills(['stoicism', 'n8n']);
    }
  };

  return (
    <div className="w-full h-screen bg-gradient-to-br from-black via-purple-900 to-black">
      <Canvas
        camera={{ position: [20, 15, 20], fov: 50 }}
        gl={{ antialias: true, alpha: true }}
      >
        <Scene
          masteredSkills={masteredSkills}
          selectedNode={selectedNode}
          setSelectedNode={setSelectedNode}
          skillNodes={skillNodes}
          consciousnessActivated={consciousnessActivated}
          masteredByLayer={masteredByLayer}
        />
      </Canvas>
      
      {/* UI Overlay */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="flex flex-col h-full justify-between p-8">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <h1 className="text-4xl font-bold text-white mb-2">
              CONSCIOUSNESS EVOLUTION
            </h1>
            <p className="text-white/60">
              {masteredSkills.length}/13 Disciplines Integrated
            </p>
            {consciousnessActivated && (
              <p className="text-cyan-400 mt-2 animate-pulse">
                UNIVERSAL CONSCIOUSNESS ACHIEVED
              </p>
            )}
          </motion.div>
          
          {/* Controls */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="absolute top-8 left-8 pointer-events-auto"
          >
            <button
              onClick={testProgression}
              className="bg-white/10 backdrop-blur-md rounded-lg px-4 py-2 border border-white/20 text-white hover:bg-white/20 transition-all"
            >
              Evolve ({masteredSkills.length}/13)
            </button>
          </motion.div>
          
          {/* Legend */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex justify-center gap-8"
          >
            <div className="bg-black/40 backdrop-blur-md rounded-lg p-4 border border-white/20">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-3 h-3 rounded-full bg-red-400" />
                <span className="text-white/80 text-sm">Body (Physical)</span>
              </div>
              <div className="flex items-center gap-3 mb-3">
                <div className="w-3 h-3 rounded-full bg-cyan-400" />
                <span className="text-white/80 text-sm">Spirit (Emotional)</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-yellow-400" />
                <span className="text-white/80 text-sm">I Am (Awareness)</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default PATHsassin3DMermaid;