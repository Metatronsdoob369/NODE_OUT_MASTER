# ANYM⁸ — Vite + React wire‑up

This patch adds:
- `/waitlist` route (React) that posts to Netlify **/api/subscribe** → Firestore.
- `ActivatePanel` overlay that mounts your 3D scene (`PATHsassin3DMermaid`) with ESC/close.
- Netlify functions + redirects for serverless subscribe.
- SPA fallback for React Router.

## Merge steps
1. Copy `src/pages/Waitlist.tsx` and `src/components/ActivatePanel.tsx` into your project (paths assume `src/` at repo root).
2. Replace your `src/App.tsx` with `App.withWaitlist.tsx` (or merge the `/waitlist` route + `ActivatePanel` bits).
3. Copy `react_netlify/` to project root and **merge** `netlify.toml` (or rename if you already have one; combine redirects/functions).
4. In Netlify → **Site settings → Environment variables**, set `FIREBASE_SERVICE_ACCOUNT` to the **full JSON** of a service account with Firestore write access.
5. Deploy. Hit `/waitlist` and submit—check Firestore for a new doc under `waitlist`.

If serverless fails, the component falls back to local CSV so you never lose a lead.

> Your tsconfig already supports `@/*` imports, so `ActivatePanel` can import `PATHsassin3DMermaid` via `@/PATHsassin3DMermaid`. If you keep that file in another folder, adjust the import accordingly.
