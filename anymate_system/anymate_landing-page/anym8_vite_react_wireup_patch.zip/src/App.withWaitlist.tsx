import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, Outlet } from 'react-router-dom';
import Waitlist from './pages/Waitlist';
import PATHsassin3DMermaid from './PATHsassin3DMermaid';
import ActivatePanel from './components/ActivatePanel';

function Home() {
  const [open, setOpen] = useState(false);
  return (
    <div style={{minHeight:'100vh', background:'#0b0d12', color:'#e6eefc', position:'relative'}}>
      <header style={{display:'flex', justifyContent:'space-between', alignItems:'center', padding:'16px 24px'}}>
        <div style={{fontWeight:800}}>ANYM⁸</div>
        <nav style={{display:'flex', gap:16}}>
          <Link to="/waitlist">Waitlist</Link>
          <button onClick={()=>setOpen(true)} aria-expanded={open} aria-controls="activate-panel" style={{padding:'.6rem .9rem', borderRadius:10, border:'1px solid rgba(255,255,255,.15)', background:'rgba(255,255,255,.04)', color:'#fff'}}>ACTIVATE</button>
        </nav>
      </header>
      <main style={{padding:'2rem'}}>
        <h1>Make. Test. Sell.</h1>
        <p>Math‑powered 3D asset generation with a marketplace for creators and buyers.</p>
        <div style={{height:360, borderRadius:16, overflow:'hidden', border:'1px solid rgba(255,255,255,.1)'}}>
          <PATHsassin3DMermaid />
        </div>
      </main>
      <ActivatePanel open={open} onClose={()=>setOpen(false)} />
    </div>
  );
}

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/waitlist" element={<Waitlist />} />
        <Route path="*" element={<Home />} />
      </Routes>
    </Router>
  );
}

export default App;
