import React, { useEffect } from 'react';
import PATHsassin3DMermaid from '@/PATHsassin3DMermaid'; // relies on tsconfig baseUrl + paths
// Fallback import if JS version is present
// import PATHsassin3DMermaid from '@/PATHsassin3DMermaid.js';

type Props = {
  open: boolean;
  onClose: () => void;
};

const ActivatePanel: React.FC<Props> = ({ open, onClose }) => {
  useEffect(() => {
    function onKey(e: KeyboardEvent){ if (e.key === 'Escape') onClose(); }
    if (open) document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div role="dialog" aria-modal="true" aria-label="Activation panel"
      style={{ position:'fixed', inset:0, background:'rgba(0,0,0,.72)', backdropFilter:'blur(6px)', display:'grid', placeItems:'center', zIndex:60 }}>
      <div style={{ position:'relative', width:'min(1200px, 92vw)', height:'min(720px, 80vh)', borderRadius:16, overflow:'hidden', border:'1px solid rgba(255,255,255,.12)' }}>
        <button onClick={onClose} aria-label="Close"
          style={{ position:'absolute', top:12, right:12, zIndex:10, background:'rgba(0,0,0,.5)', color:'#fff', border:'1px solid rgba(255,255,255,.2)', borderRadius:10, padding:'8px 10px', cursor:'pointer' }}>
          Close
        </button>
        {/* 3D scene */}
        <PATHsassin3DMermaid />
      </div>
    </div>
  );
};

export default ActivatePanel;
